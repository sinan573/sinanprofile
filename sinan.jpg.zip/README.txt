# Sinan - Personal Portfolio & Digital CV

## Included Files:
- `index.html`: Main bright & vibrant website file featuring all 8 tabs, image links, and custom CSS styling.
- `sinan.jpg`: Your high-resolution portrait image embedded into the site.
- `README.txt`: Project documentation.

## How to Run:
1. Extract all files into a single folder.
2. Double-click `index.html` to open your complete website in any browser.
3. Click "sinan profile" at the top right to verify your profile badge.
